create view v_category as
  select `qingcheng_goods`.`tb_category`.`id` AS `id`, `qingcheng_goods`.`tb_category`.`name` AS `NAME`
  from `qingcheng_goods`.`tb_category`
  where (`qingcheng_goods`.`tb_category`.`parent_id` = 0);

